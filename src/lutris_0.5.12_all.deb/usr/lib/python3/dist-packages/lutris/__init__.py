"""Main Lutris package"""

__version__ = "0.5.12"
